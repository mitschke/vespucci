package controller.test;

public class MainController {
	
	public static char doSome(int[] te){
		System.out.println("did some controllingcontrol"); // Allowed
		return 0;
	}
	
}
