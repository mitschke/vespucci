package controller;

import model.DataModel;

public class MainController {
	
	
	public static void doSome(){
		System.out.println("did some controllingcontrol"); // Allowed
	}
	
}
