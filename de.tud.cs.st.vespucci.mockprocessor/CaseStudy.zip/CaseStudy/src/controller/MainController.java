package controller;

public class MainController {
	
	public static char doSome(int[] te){
		System.out.println("did some controllingcontrol"); // Allowed
		return 0;
	}
	
	class InnerController$InnerInnerConroller{
		
		private String someString;
		
		class InnerInnerController{
			
			public void doSomething(){
				System.out.println(someString);
				
			}
		}
	}
	
}
