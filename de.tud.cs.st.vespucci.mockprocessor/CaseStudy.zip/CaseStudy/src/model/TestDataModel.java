package model;

import view.ViewMain;
import controller.test.MainController;

public class TestDataModel {

	public static void main(String[] args) {

		TestDataModel model = new TestDataModel(); // intern
		model.callController(); // intern
		model.createView("Value"); // intern
		
	}

	private int createView(String value) { // Whole Method not allowed
		
		ViewMain view = new ViewMain(); // Not Allowed
		view.show(); // Not Allowed
		
		return 1;
	}

	public TestDataModel() {

	}

	private void callController() {

		MainController.doSome(null); // Not allowed

	}

}
