package model;

import view.MainView;
import controller.MainController;

public class DataModel {

	public static void main(String[] args) {

		DataModel model = new DataModel(); // intern
		model.callController(); // intern
		model.createView(); // intern

	}

	private void createView() { // Whole Method not allowed
		
		MainView view = new MainView(); // Not Allowed
		view.show(); // Not Allowed
		
	}

	public DataModel() {

	}

	private void callController() {

		MainController.doSome(); // Not allowed

	}
}
