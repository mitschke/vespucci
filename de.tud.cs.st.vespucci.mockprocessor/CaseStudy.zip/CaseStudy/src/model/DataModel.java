package model;


import view.MainView;
import view.MainView.SubView;
import controller.MainController;

public class DataModel {
	
	String field2 = "hello";
	
	public static void main(String[] args) {		
		DataModel model = new DataModel(); // intern
		model.callController(); // intern
		model.createInnerView("Value"); // intern

	}

	private String[] createInnerView(String value) { // Whole Method not allowed
		
		System.out.println(field2); // Not Allowed
		
		final MainView view = new MainView(); // Not Allowed
		SubView view2 = view.new SubView(); // Not Allowed
		view2.show(); // Not Allowed
		
		return null;
	}

	public DataModel() {

	}

	private void callController() {

		MainController.doSome(null); // Not allowed

	}
}
