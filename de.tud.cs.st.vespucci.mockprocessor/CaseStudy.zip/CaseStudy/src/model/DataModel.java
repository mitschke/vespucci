package model;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import view.ViewMain;
import controller.test.MainController;

public class DataModel {

	String[] test = {"wow"};

	private DataModel dataModel;
	
	public static void main(String[] args) {		
		DataModel model = new DataModel(); // intern
		model.callController(); // intern
		model.createView("Value"); // intern

	}

	private String[] createView(String value) { // Whole Method not allowed
		
		dataModel = dataModel;
		
		final ViewMain view = new ViewMain(); // Not Allowed
		view.show(); // Not Allowed
		
		JButton test = new JButton("Test");
		
		test.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				view.show();
			}
		});
		
		return null;
	}

	public DataModel() {

	}

	private void callController() {

		MainController.doSome(null); // Not allowed

	}
}
