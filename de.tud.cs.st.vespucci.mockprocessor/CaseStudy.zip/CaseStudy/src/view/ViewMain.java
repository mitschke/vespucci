package view;

import java.util.LinkedList;

import javax.swing.JFrame;

public class ViewMain {

	public void show(){
		System.out.println("Here I am, rock you like a hurricane");
		
		JFrame frame = new JFrame();
		frame.setBounds(100, 100, 200, 200);
		frame.setVisible(true);
	}
	
	
	public String getBlub(){
		return null;
		
	}
	
	class MainView {

		public void show(){
			System.out.println("Here I am, rock you like a hurricane");
			
			JFrame frame = new JFrame();
			frame.setBounds(100, 100, 200, 200);
			frame.setVisible(true);
		}
	}
}


