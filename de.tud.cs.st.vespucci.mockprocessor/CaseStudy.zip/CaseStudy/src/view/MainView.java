package view;

import javax.swing.JFrame;

public class MainView {

	public void show(){
		System.out.println("Here I am, rock you like a hurricane");
		
		JFrame frame = new JFrame();
		frame.setBounds(100, 100, 200, 200);
		frame.setVisible(true);
	}
	
	
	public String getBlub(){
		return null;
		
	}
	
	public class SubView {

		public void show(){
			System.out.println("Here I am, rock you like a hurricane");
			
			JFrame frame = new JFrame();
			frame.setBounds(100, 100, 200, 200);
			frame.setVisible(true);
			
		}
	}
}


