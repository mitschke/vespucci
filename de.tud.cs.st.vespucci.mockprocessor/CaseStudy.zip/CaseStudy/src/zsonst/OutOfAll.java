package zsonst;

public class OutOfAll {

}
