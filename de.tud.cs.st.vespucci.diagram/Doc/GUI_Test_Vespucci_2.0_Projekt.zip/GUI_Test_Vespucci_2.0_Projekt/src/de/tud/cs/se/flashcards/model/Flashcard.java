/** License (BSD Style License):
 *  Copyright (c) 2010
 *  Software Engineering
 *  Department of Computer Science
 *  Technische Universität Darmstadt
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  - Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  - Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  - Neither the name of the Software Engineering Group or Technische 
 *    Universität Darmstadt nor the names of its contributors may be used to 
 *    endorse or promote products derived from this software without specific 
 *    prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 *  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 *  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 *  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 */
package de.tud.cs.se.flashcards.model;

import java.awt.Dimension;
import java.io.Serializable;
import java.util.Date;
import java.util.LinkedList;

import de.tud.cs.st.contraints.NotNull;
import de.tud.cs.st.contraints.Null;
import de.tud.cs.st.structure.gof.observer.ConcreteSubject;


/**
 * Every flashcard consists of two parts: (i) a question and (ii) an answer to the question.
 * Additionally, meta information is associated with each flashcard to implement different learning
 * strategies.
 * 
 * @author Michael Eichberg
 */
@ConcreteSubject("FlashcardObserver") public class Flashcard implements Serializable {

	// TODO Get rid of Java serialization!
	private static final long serialVersionUID = 200L;


	/**
	 * The width of a flashcard.
	 */
	public static final int WIDTH = 600;


	/**
	 * The height of a flashcard.
	 */
	public static final int HEIGHT = 400;


	/**
	 * The dimension of flashcards.
	 * 
	 * @see #WIDTH
	 * @see #HEIGHT
	 */
	public static final Dimension FLASHCARD_DIMENSION = new Dimension(WIDTH, HEIGHT);


	// TODO As soon as we do no longer use Java serialization make this object final!
	private transient LinkedList<FlashcardObserver> observers;


	private final Date created = new Date();


	private Date remembered = null;


	private Date notRemembered = null;


	private int shownCount = 0;


	private int notRememberedCount = 0;


	private int rememberedInARowCount = 0;


	private String question;


	private String answer;


	public Flashcard(@NotNull String question, @NotNull String answer) {

		this.question = question;
		this.answer = answer;
	}

	
	//inner class implements the Iterator pattern
    private class InnerEvenIterator {
        private static final int SIZE = 0;
		//start stepping through the array from the beginning
        private int next = 0;
        
        public boolean hasNext() {
            //check if a current element is the last in the array
            return (next <= SIZE - 1);
        }
        
        public int getNext() {
            int[] arrayOfInts = null;
			//record a value of an even index of the array
            int retValue = arrayOfInts[next];
            //get the next even element
            next += 2;
            return retValue;
        }
        
        
        
        private class InnerEvenIterator2222 {
            private static final int SIZE = 0;
    		//start stepping through the array from the beginning
            private int next = 0;
            
            public boolean hasNext() {
                //check if a current element is the last in the array
                return (next <= SIZE - 1);
            }
            
            public int getNext() {
                int[] arrayOfInts = null;
    			//record a value of an even index of the array
                int retValue = arrayOfInts[next];
                //get the next even element
                next += 2;
                return retValue;
            }
        }
    }

	

	/**
	 * Creates a new empty flashcard.
	 */
	public Flashcard() {

		this("", "");
	}


	public synchronized void addObserver(@NotNull FlashcardObserver flashcardObserver) {

		if (observers == null)
			observers = new LinkedList<FlashcardObserver>();

		observers.addFirst(flashcardObserver);
	}


	public synchronized void removeObserver(@NotNull FlashcardObserver flashcardObserver) {

		observers.remove(flashcardObserver);
	}


	protected void notifyFlashcardObervers() {

		FlashcardObserver[] observers;
		synchronized (this) {
			if (this.observers == null)
				return;

			// required to enable an observer to remove itself from the list of
			// observers...
			observers = this.observers.toArray(new FlashcardObserver[this.observers.size()]);
		}
		for (FlashcardObserver observer : observers) {
			observer.cardChanged(this);
		}
	}


	public void setAnswer(@NotNull String answer) {

		this.answer = answer;

		notifyFlashcardObervers();
	}


	public void setQuestion(@NotNull String question) {

		this.question = question;

		notifyFlashcardObervers();
	}


	public void setNotRemembered(@NotNull Date notRemembered) {

		this.notRemembered = notRemembered;
		this.rememberedInARowCount = 0;
		this.shownCount++;
		this.notRememberedCount++;

		notifyFlashcardObervers();
	}


	public void setRemembered(@NotNull Date remembered) {

		this.remembered = remembered;
		this.rememberedInARowCount++;
		this.shownCount++;

		notifyFlashcardObervers();
	}


	public @NotNull String getAnswer() {

		return answer;
	}


	public @NotNull String getQuestion() {

		return question;
	}


	public @Null Date getNotRemembered() {

		return notRemembered;
	}


	public int getNotRememberedCount() {

		return notRememberedCount;
	}


	public @Null Date getRemembered() {

		return remembered;
	}


	public @NotNull Date getCreated() {

		return created;
	}


	public int getShownCount() {

		return shownCount;
	}


	public int getRememberedInARowCount() {

		return rememberedInARowCount;
	}


	public boolean contains(@NotNull String searchTerm) {

		return question.contains(searchTerm) || answer.contains(searchTerm);
	}

}