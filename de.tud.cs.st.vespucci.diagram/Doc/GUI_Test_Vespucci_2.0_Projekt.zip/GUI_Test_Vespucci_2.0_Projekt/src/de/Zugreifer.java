package de;

public class Zugreifer {
	
	public Zugreifer() {
		Zugegriffen t = new Zugegriffen();
		int getted = t.getAccess();
	}

}
