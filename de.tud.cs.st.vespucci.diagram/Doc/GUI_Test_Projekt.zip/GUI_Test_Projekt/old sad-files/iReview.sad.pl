%------
% Prolog based representation of the Vespucci architecture diagram: F:\runtime-EclipseApplication(1)\GUI_Test_Projekt\old sad-files/iReview.sad
% Created by Vespucci, Technische Universität Darmstadt, Department of Computer Science
% www.opal-project.de

:- multifile ensemble/5.
:- multifile abstract_ensemble/5.
:- multifile outgoing/7.
:- multifile incoming/7.
:- multifile not_allowed/7.
:- multifile expected/7.
:- discontiguous ensemble/5.
:- discontiguous abstract_ensemble/5.
:- discontiguous outgoing/7.
:- discontiguous incoming/7.
:- discontiguous not_allowed/7.
:- discontiguous expected/7.

% Date <08/09/2011 17:34:43>.
%------

%------
%ensemble(File, Name, Ensemble Parameter, Query, SubEnsembles) :- Definition of an ensemble
%	File - The simple file name in which the ensemble is defined (e.g., 'Flashcards.sad')
%	Name - Name of the ensemble
%	Ensemble Parameter - Parameter of the ensemble
%	Query - Query that determines which source elements belong to the ensemble
%	SubEnsembles - List of all sub ensembles of this ensemble
%------
ensemble('iReview.sad', 'commons.io', [], (empty), []).
ensemble('iReview.sad', 'iReview', [], (derived), ['DTOs', 'Server', 'RMI Client']).
ensemble('iReview.sad', 'DTOs', [], (empty), []).
ensemble('iReview.sad', 'Server', [], (derived), ['RESTFul Server', 'Server Startup/Server Runtime', 'RMI Server']).
ensemble('iReview.sad', 'RESTFul Server', [], (package('de.tud.cs.dea.presentations.server.restful') ), []).
ensemble('iReview.sad', 'Server Startup/Server Runtime', [], (empty), []).
ensemble('iReview.sad', 'RMI Server', [], (empty), []).
ensemble('iReview.sad', 'RMI Client', [], (empty), []).
ensemble('iReview.sad', 'org.restlet', [], (empty), []).
ensemble('iReview.sad', 'Scala Library', [], (empty), []).
ensemble('iReview.sad', 'db4o', [], (empty), []).
ensemble('iReview.sad',(empty),empty,[]).

%------
%DEPENDENCY(File, ID, SourceE, SourceE Parameter, TargetE, TargetE Parameter, Type) :- Definition of a dependency between two ensembles.
%	DEPENDENCY - The type of the dependency. Possible values: outgoing, incoming, expected, not_allowed
%	File - The simple file name in which the dependency is defined (e.g., 'Flashcards.sad')
%	ID - An ID identifying the dependency
%	SourceE - The source ensemble
%	SourceE Parameter - Parameter of the source ensemble
%	TargetE - The target ensemble
%	TargetE Parameter - Parameter of the target ensemble
%	Relation classifier - Kinds of uses-relation between source and target ensemble (all, field_access, method_call,...)
%------
outgoing('iReview.sad', 1, 'DTOs', [], empty, [], [all]).
incoming('iReview.sad', 2, 'Server', [], 'Scala Library', [], [all]).
incoming('iReview.sad', 3, 'Server', [], 'db4o', [], [all]).
not_allowed('iReview.sad', 4, 'Server', [], 'RMI Client', [], [all]).
incoming('iReview.sad', 5, 'RESTFul Server', [], 'org.restlet', [], [all]).
expected('iReview.sad', 6, 'Server Startup/Server Runtime', [], 'RMI Server', [], [all]).
expected('iReview.sad', 7, 'Server Startup/Server Runtime', [], 'RESTFul Server', [], [all]).
not_allowed('iReview.sad', 8, 'RESTFul Server', [], 'RMI Server', [], [all]).
outgoing('iReview.sad', 9, 'Server Startup/Server Runtime', [], 'RESTFul Server', [], [all]).
outgoing('iReview.sad', 10, 'Server Startup/Server Runtime', [], 'RMI Server', [], [all]).
incoming('iReview.sad', 11, 'RMI Server', [], 'DTOs', [], [all]).
not_allowed('iReview.sad', 12, 'RMI Server', [], 'RESTFul Server', [], [all]).
incoming('iReview.sad', 13, 'RMI Client', [], 'commons.io', [], [all]).
outgoing('iReview.sad', 13, 'RMI Client', [], 'commons.io', [], [all]).
incoming('iReview.sad', 14, 'RMI Client', [], 'DTOs', [], [all]).
outgoing('iReview.sad', 14, 'RMI Client', [], 'DTOs', [], [all]).
