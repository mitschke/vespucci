package de;

public class Zugegriffen {
	
	public int accessed;
	
	public int getAccess() {
		return accessed;
	}

}
