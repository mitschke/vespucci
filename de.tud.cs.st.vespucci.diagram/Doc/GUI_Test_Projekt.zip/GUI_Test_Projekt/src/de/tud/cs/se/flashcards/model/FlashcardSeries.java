/** License (BSD Style License):
 *  Copyright (c) 2010
 *  Software Engineering
 *  Department of Computer Science
 *  Technische Universität Darmstadt
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  - Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  - Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  - Neither the name of the Software Engineering Group or Technische 
 *    Universität Darmstadt nor the names of its contributors may be used to 
 *    endorse or promote products derived from this software without specific 
 *    prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 *  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 *  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 *  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 */
package de.tud.cs.se.flashcards.model;

import javax.swing.ListModel;
import javax.swing.event.ListDataListener;

import de.tud.cs.st.contraints.NotNull;
import de.tud.cs.st.structure.gof.decorator.Component;


/**
 * A flashcards list manages flashcards.
 * 
 * @author Michael Eichberg
 */
@Component("FlashcardSeries") public interface FlashcardSeries extends ListModel {

	/**
	 * Adds the given listener.
	 * <p>
	 * It is an error to register the same listener twice!
	 * </p>
	 */
	void addListDataListener(@NotNull ListDataListener l);


	/**
	 * Removes the given, registered listener.
	 * <p>
	 * It is an error to request removing a listener that is not (no longer) registered.
	 * </p>
	 */
	void removeListDataListener(@NotNull ListDataListener l);


	/**
	 * Adds the given card to this series; a card is always added as the first card to the core data
	 * model. The card must not belong to any flashcards list.
	 */
	void addCard(@NotNull Flashcard flashcard);


	/**
	 * Removes the flashcards with the indices. A flashcard that was removed can be added to another
	 * series.
	 * 
	 * @param indices
	 *           the indices of the flashcards that have to be removed. The array has to be sorted in
	 *           ascending order.
	 */
	void removeCards(@NotNull int[] indices);


	/**
	 * @return The card with the given index.
	 */
	@NotNull Flashcard getElementAt(int index) throws IndexOutOfBoundsException;


	/**
	 * @return The number of flashcards.
	 */
	int getSize();


	/**
	 * @return The flashcard series that maintains the core data model.
	 */
	@NotNull FlashcardSeries getSourceModel();
}