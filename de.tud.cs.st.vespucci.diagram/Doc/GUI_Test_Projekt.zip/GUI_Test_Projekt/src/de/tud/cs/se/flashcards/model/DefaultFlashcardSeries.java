/** License (BSD Style License):
 *  Copyright (c) 2010
 *  Software Engineering
 *  Department of Computer Science
 *  Technische Universität Darmstadt
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  - Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  - Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  - Neither the name of the Software Engineering Group or Technische 
 *    Universität Darmstadt nor the names of its contributors may be used to 
 *    endorse or promote products derived from this software without specific 
 *    prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 *  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 *  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 *  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 */
package de.tud.cs.se.flashcards.model;

import java.util.ArrayList;
import java.util.List;

import de.tud.cs.st.contraints.NotNull;
import de.tud.cs.st.structure.gof.decorator.ConcreteComponent;


/**
 * A series represents a set of flashcards and basically provides a set of management functions.
 * 
 * @author Michael Eichberg
 */
@ConcreteComponent("FlashcardSeries") public class DefaultFlashcardSeries extends
		AbstractFlashcardSeries {
	// We did deliberately not extend "AbstractListModel" to avoid that Java Serialization of this
	// (then Serializable) class would store references to listeners that do not belong to the model
	// layer.

	/**
	 * Convenience method to create an initial flashcard series.
	 */
	public static @NotNull DefaultFlashcardSeries createInitialFlashcardSeries() {

		DefaultFlashcardSeries flashcards = new DefaultFlashcardSeries();
		flashcards.addCard(new Flashcard("lose Kopplung", "loose coupling"));
		flashcards.addCard(new Flashcard("hoher Zusammenhalt", "high cohesion"));
		flashcards.addCard(new Flashcard("Stellvertreter", "Proxy"));
		flashcards.addCard(new Flashcard("Entwurfsmuster", "Design Pattern"));
		flashcards.addCard(new Flashcard("Beispiel", "Example"));
		flashcards.addCard(new Flashcard("Haus", "House"));
		flashcards.addCard(new Flashcard("Hund", "Dog"));
		flashcards.addCard(new Flashcard("Erinnerung", "Memento"));

		return flashcards;
	}


	private final FlashcardObserver observer = new FlashcardObserver() {

		// By using an inner class to implement the FlashcardObserver interface instead of
		// letting "FlashcardSeries" directly implement the interface, we do not need to
		// expose this method to clients of the outer class. This avoids pollution of the outer
		// class' (public) interface.
		public void cardChanged(Flashcard flashcard) {

			int index = flashcards.indexOf(flashcard);
			fireContentsUpdated(DefaultFlashcardSeries.this, index, index);
		}
	};


	// Stores all flashcards.
	private final List<Flashcard> flashcards = new ArrayList<Flashcard>();


	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * de.tud.cs.se.flashcards.model.FlashcardSeries#addCard(de.tud.cs.se.flashcards.model.Flashcard)
	 */
	public void addCard(@NotNull Flashcard flashcard) {

		flashcards.add(0, flashcard);
		fireIntervalAdded(this, 0, 0);
		flashcard.addObserver(observer);
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see de.tud.cs.se.flashcards.model.FlashcardSeries#removeCards(int[])
	 */
	public void removeCards(@NotNull int[] indices) {

		// we have to start from the end to avoid deleting "arbitrary cards"
		for (int i = indices.length - 1; i >= 0; i--) {
			int index = indices[i];
			flashcards.get(index).removeObserver(observer);
			flashcards.remove(index);
			fireIntervalRemoved(this, index, index);
		}
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see de.tud.cs.se.flashcards.model.FlashcardSeries#getElementAt(int)
	 */
	public @NotNull Flashcard getElementAt(int index) throws IndexOutOfBoundsException {

		return flashcards.get(index);
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see de.tud.cs.se.flashcards.model.FlashcardSeries#getSize()
	 */
	public int getSize() {

		return flashcards.size();
	}


	/**
	 * @return <code>this</code>.
	 */
	public FlashcardSeries getSourceModel() {

		return this;
	}

}
