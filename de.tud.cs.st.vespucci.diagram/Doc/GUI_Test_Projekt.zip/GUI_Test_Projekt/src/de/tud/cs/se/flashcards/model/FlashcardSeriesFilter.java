/** License (BSD Style License):
 *  Copyright (c) 2010
 *  Software Engineering
 *  Department of Computer Science
 *  Technische Universität Darmstadt
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  - Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  - Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  - Neither the name of the Software Engineering Group or Technische 
 *    Universität Darmstadt nor the names of its contributors may be used to 
 *    endorse or promote products derived from this software without specific 
 *    prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 *  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 *  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 *  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 */
package de.tud.cs.se.flashcards.model;

import java.util.ArrayList;

import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;

import de.tud.cs.st.contraints.NotNull;
import de.tud.cs.st.structure.gof.decorator.ConcreteDecorator;


/**
 * This flashcard series acts as a filter for another flashcard series.
 * <p>
 * The flashcard series is maintained in response to change events issued by the underlying
 * flashcard series; this series just maintains a list of indices pointing to the "real" flashcards
 * in the underlying FlashcardSeries. By making this decorator an observer of the underlying series,
 * operations that are directly called on the underlying flashcard series - and do manipulate the
 * series - are supported. The filtered list always reflects the correct state.
 * </p>
 * 
 * @version $Rev: 134 $ $Date: 2010-03-22 13:11:00 +0100 (Mon, 22 Mar 2010) $
 * @author Michael Eichberg
 */
@ConcreteDecorator("FlashcardSeries") public class FlashcardSeriesFilter extends
		AbstractFlashcardSeries {

	/**
	 * The underlying flashcard series.
	 */
	private final FlashcardSeries flashcardSeries;


	// This array's content is always sorted in ascending order!
	private final ArrayList<Integer> flashcardIndices = new ArrayList<Integer>();


	// We did not let FlashcardSeriesFilter directly implement the ListDataListener interface
	// to avoid polluting the public interface. Additionally, the code to handle changes of
	// the underlying flashcard series is well modularized.
	private final ListDataListener listDataListener = new ListDataListener() {

		public void intervalAdded(ListDataEvent e) {

			int u_startIndex = e.getIndex0();
			int u_endIndex = e.getIndex1();

			assert u_startIndex <= u_endIndex;

			// 1. we have to find the place where we want to "potentially" insert the elements
			// TODO Use binary search algorithm...
			int index = 0;
			while (index < flashcardIndices.size() && flashcardIndices.get(index) < u_startIndex)
				index++;

			// 2. update the existing references
			int insertCount = u_endIndex - u_startIndex + 1;
			for (int i = index; i < flashcardIndices.size(); i++) {
				flashcardIndices.set(i, flashcardIndices.get(i) + insertCount);
			}

			// 3. let's check if we have to insert some of the cards
			for (int u_index = u_startIndex; u_index <= u_endIndex; u_index++) {
				if (accept(flashcardSeries.getElementAt(u_index))) {
					flashcardIndices.add(index, u_index);
					fireIntervalAdded(FlashcardSeriesFilter.this, index, index);
					index++;
				}
			}
		}


		public void contentsChanged(ListDataEvent e) {

			// We may have to "remove / add" elements, hence we have to start filtering from the end!
			int u_startIndex = e.getIndex0(); // u_ => index w.r.t. the underlying series
			int u_endIndex = e.getIndex1();

			assert u_endIndex >= u_startIndex;

			int index = flashcardIndices.size() - 1;

			for (int u_index = u_endIndex; u_index >= u_startIndex; u_index--) {

				// let's search for the card with the current index
				while (index >= 0 && flashcardIndices.get(index) > u_index)
					index--;

				if (index >= 0 && flashcardIndices.get(index) == u_index) {
					// The card is not filtered (we did find the index) ...

					if (!accept(flashcardSeries.getElementAt(u_index))) {
						// ... but we have to filter it now.
						flashcardIndices.remove(index);
						fireIntervalRemoved(FlashcardSeriesFilter.this, index, index);
					} else {
						fireContentsUpdated(FlashcardSeriesFilter.this, index, index);
					}
				} else { // also handles the case "index == -1"
					// The card is currently filtered...
					if (accept(flashcardSeries.getElementAt(u_index))) {
						// ... now we have to include it.
						flashcardIndices.add(index + 1, u_index);
						fireIntervalAdded(FlashcardSeriesFilter.this, index + 1, index + 1);
					}
				}
			}
		}


		public void intervalRemoved(ListDataEvent e) {

			int u_startIndex = e.getIndex0();
			int u_endIndex = e.getIndex1();

			int endIndex = -1;
			int startIndex = flashcardIndices.size();

			assert u_startIndex <= u_endIndex;

			for (int i = flashcardIndices.size() - 1; i >= 0; i--) {
				if (flashcardIndices.get(i) >= u_startIndex && flashcardIndices.get(i) <= u_endIndex) {

					if (i > endIndex)
						endIndex = i;
					if (i < startIndex)
						startIndex = i;

					flashcardIndices.remove(i);
					// update the indices...
					for (int j = i; j < flashcardIndices.size(); j++) {
						flashcardIndices.set(j, flashcardIndices.get(j) - 1);
					}
				}
			}
			if (startIndex > -1 /* && endIndex >= startIndex */) {
				assert startIndex <= endIndex;
				// we did remove some cards...
				fireIntervalRemoved(FlashcardSeriesFilter.this, startIndex, endIndex);
			}
		}

	};


	/**
	 * Stores the current search term.
	 */
	private @NotNull String searchTerm = "";


	/**
	 * Constructs a new filter for flashcards that enables to dynamically filter flashcards. If no
	 * filter is set the behavior of this filter is completely transparent.
	 */
	public FlashcardSeriesFilter(@NotNull FlashcardSeries flashcardSeries) {

		for (int i = 0; i < flashcardSeries.getSize(); i++)
			flashcardIndices.add(i);

		flashcardSeries.addListDataListener(listDataListener);
		this.flashcardSeries = flashcardSeries;
	}


	/**
	 * @return The source model of the underlying flashcards list.
	 */
	public FlashcardSeries getSourceModel() {

		return flashcardSeries.getSourceModel();
	}


	public void addCard(Flashcard flashcard) {

		flashcardSeries.addCard(flashcard);

	}


	public Flashcard getElementAt(int index) throws IndexOutOfBoundsException {

		return flashcardSeries.getElementAt(flashcardIndices.get(index));
	}


	public int getSize() {

		return flashcardIndices.size();
	}


	public void removeCards(int[] indices) {

		// remap indices
		int[] realIndices = new int[indices.length];
		for (int i = indices.length - 1; i >= 0; i--) {
			realIndices[i] = flashcardIndices.get(indices[i]);
		}

		flashcardSeries.removeCards(realIndices);
	}


	public void setSearchTerm(@NotNull String searchTerm) {

		if (this.searchTerm.equals(searchTerm))
			return;

		if (searchTerm.length() == 0) {
			// reset the filter
			this.searchTerm = "";

			for (int u_index = 0; u_index < flashcardSeries.getSize(); u_index++) {
				// the idea is to reintegrate missing cards
				if (flashcardIndices.size() == u_index || flashcardIndices.get(u_index) != u_index) {
					flashcardIndices.add(u_index, u_index);
					fireIntervalAdded(this, u_index, u_index);
				}
			}

		} else if (this.searchTerm.contains(searchTerm)) {
			// some characters were removed; we may have to (re)include some flashcards...

			this.searchTerm = searchTerm;

			int index = 0;
			for (int u_index = 0; u_index < flashcardSeries.getSize(); u_index++) {
				assert index <= u_index; // loop invariant

				if (index < flashcardIndices.size() && flashcardIndices.get(index) == u_index) {
					index++;
					continue;
				}

				// either index >= flashcardIndices.size() or the flashcardIndices.get(index) is
				// refereing to a later card; hence we may have to reintegrate filtered cards
				if (accept(flashcardSeries.getElementAt(u_index))) {
					flashcardIndices.add(index, u_index);
					fireIntervalAdded(this, index, index);
					index++;
				}
			}

		} else if (searchTerm.contains(this.searchTerm)) {
			// The user added more characters; we may have to filter more flashcards...

			this.searchTerm = searchTerm; // has to be done before "accept(...)" is called

			for (int i = flashcardIndices.size() - 1; i >= 0; i--) {
				if (!accept(flashcardSeries.getElementAt(flashcardIndices.get(i)))) {
					flashcardIndices.remove(i);
					fireIntervalRemoved(this, i, i);
				}
			}

		} else {
			// the user probably pasted a string over an existing search term...
			setSearchTerm(""); // clear filter
			setSearchTerm(searchTerm); // apply filter
		}
	}


	/**
	 * @return <code>true</code>, if the card matches the search condition.
	 */
	protected boolean accept(@NotNull Flashcard flashcard) {

		return flashcard.contains(searchTerm);
	}

}
